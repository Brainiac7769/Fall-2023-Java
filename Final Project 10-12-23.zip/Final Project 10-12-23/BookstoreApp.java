//Lynn Prout
//BookstoreApp test 10-8
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookstoreApp
{
    private List<Book> availableBooks = new ArrayList<>();
    private List<Book> shoppingCart = new ArrayList<>();

    private JFrame frame;
    private JTextArea textArea;
    private JTextField nameField;
    private JTextField addressField;
    private JTextField emailField;
    private JList<Book> bookList;
    private DefaultListModel<Book> cartListModel = new DefaultListModel<>();
    private double totalCost = 0.0;

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(() -> new BookstoreApp());
    }
    public BookstoreApp()
    {
        loadAvailableBooksFromFile("books.txt");

        frame = new JFrame("Online Bookstore");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1100, 500);

        textArea = new JTextArea(10, 40);
        textArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(textArea);

        JButton addToCartButton = new JButton("Add to Cart");
        JButton checkoutButton = new JButton("Checkout");

        bookList = new JList<>(availableBooks.toArray(new Book[0]));

        addToCartButton.addActionListener(e -> addToCart());
        checkoutButton.addActionListener(e -> checkout());

        nameField = new JTextField(20);
        addressField = new JTextField(20);
        emailField = new JTextField(20);

        JLabel nameLabel = new JLabel("Name:");
        JLabel addressLabel = new JLabel("Address:");
        JLabel emailLabel = new JLabel("Email:");

        Container container = frame.getContentPane();
        container.setLayout(new BorderLayout());
        container.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addToCartButton);
        buttonPanel.add(checkoutButton);

        container.add(buttonPanel, BorderLayout.SOUTH);

        JPanel userInfoPanel = new JPanel();
        userInfoPanel.setLayout(new GridLayout(3, 2));
        userInfoPanel.add(nameLabel);
        userInfoPanel.add(nameField);
        userInfoPanel.add(addressLabel);
        userInfoPanel.add(addressField);
        userInfoPanel.add(emailLabel);
        userInfoPanel.add(emailField);

        container.add(userInfoPanel, BorderLayout.NORTH);
        
        bookList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        container.add(new JScrollPane(bookList), BorderLayout.WEST);

        JList<Book> cartList = new JList<>(cartListModel);
        container.add(new JScrollPane(cartList), BorderLayout.EAST);

        frame.setVisible(true);
        listAvailableBooks();
    }

    private void loadAvailableBooksFromFile(String filename)
    {
        try (Scanner fileScanner = new Scanner(new File(filename)))
        {
            while (fileScanner.hasNextLine())
            {
                String line = fileScanner.nextLine();
                String[] parts = line.split(",");
                if (parts.length == 3)
                {
                    String title = parts[0];
                    String author = parts[1];
                    double price = Double.parseDouble(parts[2]);
                    availableBooks.add(new Book(title, author, price));
                }
            }
        } catch (IOException e)
        {
            JOptionPane.showMessageDialog(frame, "Error loading books from file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void listAvailableBooks()
     {
        textArea.setText("Available Books:\n\n");
        for (int i = 0; i < availableBooks.size(); i++)
         {
            textArea.append(i + 1 + ". " + availableBooks.get(i) + "\n");
        }
    }
    private void addToCart()
    {
        int selectedIndex = bookList.getSelectedIndex();
        if (selectedIndex >= 0)
        {
            Book selectedBook = availableBooks.get(selectedIndex);
            shoppingCart.add(selectedBook);
            cartListModel.addElement(selectedBook); 
            totalCost += selectedBook.getPrice();
            JOptionPane.showMessageDialog(frame, selectedBook.getTitle() + " has been added to your cart.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else
        {
        JOptionPane.showMessageDialog(frame, "Please select a book to add to your cart.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void checkout()
    {
        if (shoppingCart.isEmpty())
        {
            JOptionPane.showMessageDialog(frame, "Your cart is empty. Please add books to your cart before checking out.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String name = nameField.getText();
        String address = addressField.getText();
        String email = emailField.getText();

        if (name.isEmpty() || address.isEmpty() || email.isEmpty()) 
        {
            JOptionPane.showMessageDialog(frame, "Please enter your name, address, and email to complete the purchase.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        saveOrderToFile(name, address, email);
        shoppingCart.clear();
        cartListModel.removeAllElements(); 
        nameField.setText("");
        addressField.setText("");
        emailField.setText("");
        totalCost = 0.0;
        frame.dispose();
        JOptionPane.showMessageDialog(frame, "Thank you, your order has been placed.", "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    private void saveOrderToFile(String name, String address, String email)
    {
        String orderFileName = "order.txt";
        try (PrintWriter writer = new PrintWriter(new FileWriter(orderFileName)))
        {
            writer.println("Order Details:");
            writer.println("Name: " + name);
            writer.println("Address: " + address);
            writer.println("Email: " + email);
            writer.println("Ordered Books:");
            for (Book book : shoppingCart) {
                writer.println(book.getTitle() + " by " + book.getAuthor() + " - $" + book.getPrice());
            }
            writer.println("Total Cost: $" + totalCost);
        } catch (IOException e)
        {
            JOptionPane.showMessageDialog(frame, "Error saving order to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);           
        }
    }
}
